const express = require("express");
const dotenv = require("dotenv");
const mongoose = require("mongoose");
const authRoute = require("./routes/auth");
const productRoute = require("./routes/product");
const adminRoute = require("./routes/admin");
const userRoute = require("./routes/user");
const payRoute = require("./routes/payment");
const cors = require("cors");

const app = express();

dotenv.config();
app.use(cors());
app.use(express.json());

mongoose
  .connect(process.env.MONGO_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    dbName: "intern",
  })
  .then(console.log("MongoDB connection Successfull"))
  .catch((err) => console.log(err));

app.use("/api/auth", authRoute);
app.use("/api/product", productRoute);
app.use("/api/admin", adminRoute);
app.use("/api/users", userRoute);
app.use("/api/payment", payRoute);
const PORT = process.env.PORT || "5000";
app.listen(PORT, () => {
  console.log("connected");
});
