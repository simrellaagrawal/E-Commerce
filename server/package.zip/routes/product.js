const router = require("express").Router();
const Product = require("../Schema/Product");
const { verifyTokenAndAuthorization } = require("./verifyToken");

//CREATE PRODUCT
router.post("/", async (req, res) => {
  const { productId, productCat, name, price, brand, stock, type } = req.body;
  try {
    var id = "ID" + Math.floor(Math.random() * 10000000);
    const newProduct = new Product({
      productId: id,
      productCat: productCat,
      name: name,
      price: price,
      brand: brand,
      stock: stock,
      type: type,
    });
    const savedProduct = await newProduct.save();
    res.status(200).json(savedProduct);
  } catch (err) {
    res.status(500).json(err.message);
  }
});
//UPDATE PRODUCT

router.put("/:id", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (product.username === req.body.username) {
      const updateProduct = await Product.findByIdAndUpdate(
        req.params.id,
        {
          $set: req.body,
        },
        { new: true }
      );
      res.status(200).json(updateProduct);
    } else {
      res.status(401).json("You can update only your product!");
    }
  } catch (err) {
    res.status(500).json(err.message);
  }
});

//DELETE PRODUCT
router.delete("/:id", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (product.username === req.body.username) {
      try {
        await product.deleteOne();
        res.status(200).json("product has been deleted!");
      } catch (err) {
        res.status(500).json(err.message);
      }
    }
  } catch (err) {
    res.status(500).json(err.message);
  }
});

//GET product
router.get("/:id", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    res.status(200).json(product);
  } catch (err) {
    res.status(500).json(err.message);
  }
});

//GET ALL product
router.get("/", async (req, res) => {
  const username = req.query.user;
  const productCat = req.query.productCat;
  const type = req.query.type;
  try {
    let products;
    if (username) {
      products = await Product.find({ username: username });
    } else if (productCat) {
      products = await Product.find({ productCat: productCat });
    } else if (type) {
      products = await Product.find({ type: type });
    } else {
      products = await Product.find();
    }
    res.status(200).json(products);
  } catch (err) {
    res.status(500).json(err.message);
  }
});

module.exports = router;
